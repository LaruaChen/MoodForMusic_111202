from pyexpat import model
from statistics import mode
from django.db import models
from django.contrib.auth.models import User

# Create your models here.
# 使用者札記
class Article(models.Model):
    article_id = models.AutoField(primary_key=True) #文章編號
    article_context = models.TextField('文章內容', max_length=500, null= True, blank=True) #文章內容
    draft_context = models.TextField('草稿', max_length=500, null= True, blank=True) # 草稿
    nick_name = models.CharField('暱稱', max_length=10, null=True, blank=True) # 署名(判斷是否匿名寄出的欄位)
    sencla = models.CharField('情感分類',max_length=1) #情感分類
    rectime = models.DateField('新增時間', auto_now_add=True) #創建文章的時間
    song_id = models.ForeignKey('Song', related_name='article_song_id', on_delete=models.RESTRICT) #歌曲編號外鍵    
    user_id = models.ForeignKey('auth.User', related_name='user_id', on_delete=models.RESTRICT) #使用者編號外鍵，auth是django資料庫的內建資料表名稱(關於user的資料)
    # null 是允許存進資料庫為空值，blank 是允許在後台空著不寫

# 歌曲
class Song(models.Model):
    song_id = models.AutoField(primary_key=True) #歌曲編號
    richi = models.DateField('上線日期') # 上線日期
    song_name = models.CharField('歌曲名稱', max_length=20) # 歌曲名稱
    link =  models.URLField('歌曲連結',max_length=200) #歌曲連結
    sentim_class = models.CharField('情感分類',max_length=1) #情感分類(喜、怒、哀、懼、愛、恨)
    singer_id = models.ForeignKey('Singer',related_name='song_singer_id', on_delete=models.RESTRICT) #歌手編號外鍵

# 歌手
class Singer(models.Model):
    singer_id = models.AutoField(primary_key=True) #歌手編號
    singer_name = models.CharField('歌手名稱', max_length=30) #歌手名稱